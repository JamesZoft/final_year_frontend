package com.james.erebus;

public enum FormatType {
	
	xml,
	json

}
